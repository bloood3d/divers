# coding: utf8
import os
import csv
import pyodbc
import datetime
import psycopg2
import cx_Oracle
import subprocess
import mysql.connector
from mysql.connector import errorcode
import spur


# The script connect on each server in the table 'Prm_Server' and execute the required queries to collect daily data.
# The queries are taken in the table 'Prm_SQL

# Errors will be written in the log and in the master file
def write_error(Error_Level, Error_Number, Error_Text, Error_Client, Error_Jobs_Type, Error_Jobs_ID, Error_Server,
                Error_QueryId):
    filler = [''] * (20 - 6)

    if Error_Level == 0:
        Error_Level_Mess = "Information"
    elif Error_Level == 1:
        Error_Level_Mess = "Warning"
    elif Error_Level == 2:
        Error_Level_Mess = "ERROR"
    elif Error_Level == 3:
        Error_Level_Mess = "CRITICAL"
    else:
        Error_Level_Mess = "?????"

    if Error_Number == 1:
        Error_Descripton = "Run Start"
    elif Error_Number == 2:
        Error_Descripton = "Run End	"
    elif Error_Number == 3:
        Error_Descripton = "Connection issue"
    elif Error_Number == 4:
        Error_Descripton = "Invalid Query"
    elif Error_Number == 5:
        Error_Descripton = "Unknown or Unsuported Target type"
    elif Error_Number == 6:
        Error_Descripton = "No Row Returned	"
    elif Error_Number == 7:
        Error_Descripton = "Unknown User_ID"
    elif Error_Number == 8:
        Error_Descripton = "Can't insert in master CSV"
    elif Error_Number == 9:
        Error_Descripton = "Missing User_ID"
    elif Error_Number == 10:
        Error_Descripton = "Target has no job"
    else:
        Error_Descripton = "??????"


    try:
        csv_master_writer.writerow(
            [datetime.datetime.now(), config["Run_Num"], Error_Client, Error_Jobs_Type, Error_Jobs_ID, Error_Server,
             Error_QueryId, "SAJOB_MESSAGE", Error_Level, Error_Number, Error_Text, Error_Level_Mess,
             Error_Descripton] + filler)

    except csv.Error as error:
        raise error
    except ValueError as error:
        raise ValueError('Could not convert item {}: {}', error)
    except TypeError as error:
        raise TypeError(error)


# Down here are the process to collect data on the targets, one process for each Target Type(DB, OS)

def processSql():
    if Server_Host is None:
        server_connect = Server_Name
    else:
        server_connect = Server_Host

    if Server_User == "Trusted_Connection":
        connectstring = "DRIVER={" + config[
            "SQLServer_Driver"] + "};SERVER=" + server_connect + ";DATABASE=master;Trusted_Connection=yes;"
    else:
        connectstring = "DRIVER={" + config[
            "SQLServer_Driver"] + "};SERVER=" + server_connect + ";DATABASE=master;UID=" + Server_User + ";PWD=" + Server_Pass

    try:
        print ("SQL Server " + Server_Name)
        print (connectstring)
        cnxn = pyodbc.connect(connectstring)
    except pyodbc.Error as err:
        write_error(2, 3, err, "", "", "", Server_Name, "")
    else:
        csv_master_cursor = cnxn.cursor()
        print(Server_Name + " count: " + str(len(Server_query_list)))
        for Query in Server_query_list:
            # Server_query_list.append((Job_Id, Job_Type, Job_Name, Job_Query, Job_Query_Id))
            try:
                csv_master_cursor.execute(Query[3])  ####------- Query !!!
                ##print csv_master_cursor.description
            except pyodbc.Error as err:
                write_error(2, 4, err, Query[2], Query[1], Query[0], Server_Name, Query[4])
            else:
                if csv_master_cursor.description == None:
                    write_error(1, 6, "", Job_Name, Jobs_Type, Job_Id, Server_Name, Job_Query_Id)
                else:
                    filler = [''] * (20 - len(csv_master_cursor.description))
                    for row in csv_master_cursor:
                        try:
                            row_c = [datetime.datetime.now(), config["Run_Num"], Query[2], Query[1], Query[0],
                                       Server_Name, Query[4]] + list(row) + filler
                            csv_master_writer.writerow(
                                [str(s).replace("\r\n", " ").replace("\n", " ").replace("None", "")
                                 for
                                 s in row_c])
                        except:
                            # TODO:ERROR (ERROR, Can't insert in master CSV)
                            write_error(2, 8, str(err).replace("ô", "o"), Job_Name, Job_Type, Job_Id, Server_Name,
                                        Job_Query_Id)
                            print('Error, see following line : ')
                            print(list(row))


# SQL
def processOracle():
    print('---------------------processOracle Entry-----------------------------')
    print ("Oracle Instance " + Server_Oracle_DB + " on server " + Server_Name)

    if Server_Host is None:
        connection = Server_Name
    else:
        connection = Server_Host

    dsn_tns = cx_Oracle.makedsn(connection, Server_Port, Server_Oracle_DB)

    try:
        cnxn = cx_Oracle.connect(Server_User, Server_Pass, dsn_tns)
    except cx_Oracle.Error as err:
        print ("ERROR!!!: " + str(err))
        print (Server_Name + " " + Server_Host + " " + connection + " " + Server_Oracle_DB + " " + Server_User + " " + Server_Pass)
        write_error(2, 3, str(err).replace("ô", "o"), Job_Name, Job_Type, Job_Id, Server_Name, Job_Query_Id)
        raise err
    else:
        csv_master_cursor = cnxn.cursor()
        for Query in Server_query_list:
            # Server_query_list.append((Job_Id, Job_Type, Job_Name, Job_Query, Job_Query_Id))
            try:
                csv_master_cursor.execute(Query[3])  ####------- Query !!!
                #print(csv_master_cursor.description)
            except cx_Oracle.Error as err:
                write_error(2, 4, err, Query[2], Query[1], Query[0], Server_Name, Query[4])
                raise err
            else:
                if csv_master_cursor.description == None:
                    write_error(1, 6, "", Query[2], Query[1], Query[0], Server_Name, Query[4])
                else:
                    filler = [''] * (20 - len(csv_master_cursor.description))

                    for row in csv_master_cursor:
                        try:
                            row_c = [str(datetime.datetime.now()),
                                     str(config["Run_Num"]),
                                     str(Query[2]),
                                     str(Query[1]),
                                     str(Query[0]),
                                     str(Server_Name),
                                     Query[4]] + list(row) + filler
                            # print('row_c', row_c)

                            csv_master_writer.writerow(
                                [str(s).replace("\r\n", " ").replace("\n", " ").replace("None", "")
                                 for
                                 s in row_c]) # May not work right with \r\n, add to fix : .replace("\r\n", " ").replace("\n", " ").replace("None", "")
                        except csv.Error as error:
                            raise error
                        except ValueError as error:
                            raise ValueError('Could not convert item {}: {}', error)
                        except TypeError as error:
                            raise TypeError(error)

def processMysql():
    # TODO: complete the connection process
    print("Mysql Server: " + Server_Name)

    if Server_Host is None:
        mysqlconfig = {'user': Server_User,
                  'password': Server_Pass,
                  'host': Server_Name,
                  'port': Server_Port}
    else:
        mysqlconfig = {'user': Server_User,
                  'password': Server_Pass,
                  'host': Server_Host,
                  'port': Server_Port}

    try:
        cnxn = mysql.connector.connect(**mysqlconfig)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with your user name or password")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Database does not exist")
        else:
            print(err)
        write_error(2, 3, err, "", "", "", Server_Name, "")
    else:
        csv_master_cursor = cnxn.cursor()
        for Query in Server_query_list:
            # Server_query_list.append((Job_Id, Job_Type, Job_Name, Job_Query, Job_Query_Id))
            try:
                csv_master_cursor.execute(Query[3])  ####------- Query !!!
                ##print csv_master_cursor.description
            except mysql.connector.Error as err:
                write_error(2, 4, err, Query[2], Query[1], Query[0], Server_Name, Query[4])
            else:
                if csv_master_cursor.description == None:
                    write_error(1, 6, "", Job_Name, Jobs_Type, Job_Id, Server_Name, Job_Query_Id)
                else:
                    filler = [''] * (20 - len(csv_master_cursor.description))
                    for row in csv_master_cursor:
                        try:
                            row_c = [datetime.datetime.now(), config["Run_Num"], Query[2], Query[1], Query[0],
                                       Server_Name, Query[4]] + list(row) + filler
                            csv_master_writer.writerow(
                                [str(s).replace("\r\n", " ").replace("\n", " ").replace("None", "")
                                 for
                                 s in row_c])
                        except:
                            print('Error, see following line : ')
                            print(list(row))


def processPostgresql():
    print ("PostgreSQL Server" + Server_Name)

    if Server_Host is None:
        postgreconfig = {'dbname': 'postgres',
                        'user': Server_User,
                        'password': Server_Pass,
                        'host': Server_Name,
                        'port': Server_Port}
    else:
        postgreconfig = {'dbname': 'postgres',
                        'user': Server_User,
                        'password': Server_Pass,
                        'host': Server_Host,
                        'port': Server_Port}

    try:
        cnxn = psycopg2.connect(**postgreconfig)
    except psycopg2.Error as err:
        write_error(2,3, err, "", "", "", Server_Name, "")
        print(err)
    else:
        csv_master_cursor = cnxn.cursor()
        for Query in Server_query_list:
            # Server_query_list.append((Job_Id, Job_Type, Job_Name, Job_Query, Job_Query_Id))
            try:
                csv_master_cursor.execute(Query[3])  ####------- Query !!!
            except psycopg2.Error as err:
                write_error(2, 4, err, Query[2], Query[1], Query[0], Server_Name, Query[4])
            else:
                if csv_master_cursor.description == None:
                    write_error(1, 6, "", Query[2], Query[1], Query[0], Server_Name, Query[4])
                else:
                    filler = [''] * (20 - len(csv_master_cursor.description))
                    for row in csv_master_cursor:
                        try:
                            row_c = [datetime.datetime.now(), config["Run_Num"], Query[2], Query[1], Query[0],
                                     Server_Name, Query[4]] + list(row) + filler
                            csv_master_writer.writerow(
                                [str(s).replace("\r\n", " ").replace("\n", " ").replace("None", "")
                                 for
                                 s in row_c])
                        except csv.Error as error:
                            raise ValueError(error)
                        except ValueError as error:
                            raise ValueError('Could not convert item {}: {}', error)
                        except TypeError as error:
                            raise TypeError(error)

def processSybase():
    # TODO:ERROR (Warning, Unknown or Unsuported RDBMS)
    print("Sybase Collector is not yet configured")


def processDB2():
    # TODO:ERROR (Warning, Unknown or Unsuported RDBMS)
    print("DB2 Collector is not yet configured")


# Below are all the process to collect data directly on the server

def processWindows():
    if param['Check_Windows_Loggedon_Users'] == 1:
        print("Executing the powershell script GetLoggedOnUser.ps1")
        subprocess.Popen([r'C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe',
                          '-ExecutionPolicy',
                          'Unrestricted',
                          './GetLoggedOnUser.ps1',
                          ], cwd=os.getcwd())
        # TODO : Implement correctly the getLoggedOnUser script


def OSCheck():
    # os = 'unix' # class attribute that default to unix right now.

    #if os == 'unix':
    ssh_config = {'hostname': Server_Host,
                    'username': Server_User,
                    'password': Server_Pass,
                    'port': Server_Port}

    shell = spur.SshShell(missing_host_key=spur.ssh.MissingHostKey.accept, **ssh_config)

    with shell:

        for Query in Server_query_list:

            #print Query[3]
            process = shell.run(["sh", "-c", Query[3]])
            print (Query[3])
            # process.stdin_write("ps -ef")
            # result = process.wait_for_result()
            #print process.output  # prints hello

            # result = shell.spawn(.split(" "))  #split each argument of the query to run into multiple element for spur
            #print result.output
            #filler = [''] * (20 - len(result.output))

            csv_master_cursor = io.BytesIO(unicode(process.output).encode("utf-8"))

            filler = [''] * (20 - len([io.BytesIO(process.output)]))
            print len([io.BytesIO(process.output)])

            for row in csv_master_cursor.readlines():
                try:
                    row_c = [datetime.datetime.now(),
                                                config["Run_Num"],
                                                Query[2],
                                                Query[1],
                                                Query[0],
                                                Server_Name,
                                                Query[4]] + [row] + filler

                    csv_master_writer.writerow(row_c)

                except csv.Error as error:
                    raise ValueError(error)
                except ValueError as error:
                    raise ValueError('Could not convert item {}: {}', error)
                except TypeError as error:
                    raise TypeError(error)


######### Main Program ##################

print('---------------------collector-----------------------------')
# Config Loading
config = dict()
config_file = open('Collector_Config.ini', 'r')

for line in config_file:
    eq_index = line.find('=')
    var_name = line[:eq_index].strip()
    value = line[eq_index + 1:].strip()
    config[var_name] = value

config_file.close()

config["Run_Num"] = open('Run_Num.ini').read()
open('Run_Num.ini', 'w').write(str(int(config["Run_Num"]) + 1))

# Chargement des fichiers de paramÃ¨tre
param = {'Jobs': [], 'Listes': [], 'Queries': [], 'Server': [], 'User': []}

# print(config["Param_Path"])
for Files in param:
    # print (Files)
    Param_File = csv.reader(open(config["Param_Path"] + Files + ".csv", "rt"), delimiter='~')
    for row in Param_File:
        param[Files].append(row)

try:
    csv_master_file = open("Master_File.csv", "w")
    csv_master_writer = csv.writer(csv_master_file, delimiter='~', lineterminator='\n')
except csv.Error as error:
    raise error
except ValueError as error:
    raise ValueError('Could not convert item {}: {}', error)
except TypeError as error:
    raise TypeError(error)

write_error(0, 1, "", "", "", "", "", "")

# Below code is to get the list of all jobs to run on a server and call the method to execute them

for Server in param["Server"]:
    Server_Id = Server[0]
    Server_Type = Server[1]
    Server_Name = Server[2]
    Server_Host = Server[3]
    Server_Oracle_DB = Server[4]
    Server_Port = Server[5]
    Server_UID = Server[6]
    Server_OS = Server[7]
    Server_DTQAP = Server[8]
    Server_Status = int(Server[9])
    Server_query_list = []
    Server_User = None
    Server_Pass = None
    Jobs_Type = ""

    print ('Server_Status : ' + str(Server_Status))
    if Server_Status == 1:
        # print ("Server name: " + Server_Name)
        if Server_UID != "":
            for User in param["User"]:
                if User[0] == Server_UID:
                    Server_User = User[1]
                    Server_Pass = User[2]

            if Server_User is None:
                write_error(3, 9, "N/A", "N/A", "N/A", "N/A", Server_Name, "N/A")
        else:
            if Server_Type.lower() not in ["sql", "sql7", "sql8", "sqlexp"]:
                write_error(3, 9, "N/A", "N/A", "N/A", "N/A", Server_Name, "N/A")
            else:
                Server_User = "Trusted_Connection"

        for List in param["Listes"]:
            ListID = int(List[0])
            List_Server_Id = List[1]

            # print ("Server_Id:" + Server_Id + "---List_Server_Id:" + List_Server_Id)
            # print ("Server_Type:" + Server_Type + "---List_Server_Id:" + List_Server_Id)

            if (Server_Type == List_Server_Id) or (Server_Id == List_Server_Id):
                # print('It should get to here at least 2 time')
                for Jobs in param["Jobs"]:
                    Job_Id = Jobs[0]
                    Job_Type = Jobs[1]
                    Job_Name = Jobs[2]
                    Job_server_list = int(Jobs[3])
                    Job_Query_Id = int(Jobs[4])
                    Job_Status = int(Jobs[6])
                    Job_Query = ""

                    if Job_Status == 1:
                        # print ("Job_Name: " + Job_Name)
                        # print ("Job_Status: " + str(Job_Status))
                        # print ("Job_server_List: " + str(Job_server_list))
                        # print ("ListID: " + str(ListID))
                        if Job_server_list == ListID:
                            # if Jobs_Type != "":
                            # if Jobs_Type != Job_Type:
                            # write_error(2, 5, Job_Type, Job_Name, Jobs_Type, Job_Id, Server_Name, Job_Query_Id)
                            # else:
                            # Jobs_Type = Job_Type

                            for Query in param["Queries"]:
                                Query_Id = int(Query[0])
                                Query_Text = Query[1]
                                Query_Name = Query[2]

                                if Query_Id == Job_Query_Id:
                                    Job_Query = Query_Text
                            Server_query_list.append((Job_Id, Job_Type, Job_Name, Job_Query, Job_Query_Id))
                            print (Server_query_list)

        if Server_Type.lower() in ["sql", "sql7", "sql8", "sqlexp"] and len(Server_query_list) > 0:
            # print (Server_query_list)
            processSql()

        elif Server_Type.lower() in ["oracle", "oracle8", "oracle9"] and len(Server_query_list) > 0:
            processOracle()

        elif Server_Type.lower() in ["db2"] and len(Server_query_list) > 0:
            processDB2()

        elif Server_Type.lower() in ["sybase"] and len(Server_query_list) > 0:
            processSybase()

        elif Server_Type.lower() in ["mysql"] and len(Server_query_list) > 0:
            print (Server_query_list)
            if Server_Port == "":
                Server_Port = 3306  # Set the default mysql Port if not already set
            processMysql()

        elif Server_Type.lower() in ["postgresql", "postgres", "postgre"] and len(Server_query_list) > 0:
            if Server_Port == "":
                Server_Port = 5432  # Set the default postgresql port if not already set
            processPostgresql()

        elif Server_Type.lower() in ["linux", "aix", "windows"] and len(Server_query_list) > 0:
            if Server_Type.lower() in ["linux", "aix"]:
                protocol = 'ssh'  # set default protocol for unix checks.
                if Server_Port == "":
                    Server_Port = 22  # set default ssh port
                    OSCheck()
            elif Server_Type.lower() == 'windows':
                protocol = 'wmi'
                print('not implemented yet')

        else:
            if len(Server_query_list) > 0:
                print ('Server Type ' + Server_Type + ' is not supported')
            else:
                print ('There is no jobs for server ' + Server_Name)
                write_error(0, 10, 0, 0, 0, 0, Server_Name, 0)

write_error(0, 2, "", "", "", "", "", "")
csv_master_file.close()
