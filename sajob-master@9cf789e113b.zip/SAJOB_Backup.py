# coding=utf-8

import os
import time
from shutil import copyfile

# Used to remove old backup
def cleanupOldLog():
    keep = 30  # config['days_to_keep_logs']
    removed = 0
    folder = sajobPath + '\Log'
    if os.name == 'posix':
        folder = sajobPath + '/Log'
    time_in_secs = time.time() - (keep * 86400)

    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        if os.stat(file_path).st_mtime < time_in_secs:
            if os.path.isfile(file_path):
                print file_path
                removed += 1
                os.remove(file_path)

    print ('The log file cleanup removed ' + str(removed) + ' files')


# ### Start Point ### #

sajobPath = 'E:\DBA\SAJOBlite'
backupPath = 'E:\DBA\BackupSAJOB'

if os.name == 'posix':
    copy2(sajobPath + '/SAJOB_DB.db', backupPath)

    os.remove(backupPath + '/SAJOB_DB.db')

else:
    copyfile(sajobPath + '\SAJOB_DB.db', backupPath)

