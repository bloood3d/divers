--------------------------------------------
-- Create new table Windows_connected_users
--------------------------------------------
CREATE TABLE Windows_connected_users(
    WCU_Id          INTEGER  PRIMARY KEY
                             NOT NULL,
    WCU_UserName    VARCHAR  NOT NULL,
    WCU_Logon_Time  DATETIME,
    WCU_SessionName VARCHAR,
    WCU_State       VARCHAR,
    WCU_Idle        DATETIME
);

--------------------------------------------------------------------
-- Recreate the view SQL_DB_Backups to add Monthly exception support
--------------------------------------------------------------------
DROP VIEW SQL_DB_Backups;
CREATE VIEW SQL_DB_Backups as
SELECT inv.SDBI_Server AS Server,
           inv.SDBI_name AS Database,
           inv.SDBI_Last_FULL AS "Last Full",
           inv.SDBI_Last_DIFF AS "Last Diff"
      FROM SQL_DB_Inventory inv
           LEFT JOIN
           Prm_Server list ON inv.SDBI_Server = list.serverName
     WHERE inv.SDBI_Current = 1 AND
           inv.SDBI_name NOT IN ('tempdb') AND
           list.DTQAP = 'P' AND
           ( (coalesce(inv.SDBI_Last_FULL, '0001-01-01 00:00:00') < datetime('now', '-1 day', 'localtime') AND
              coalesce(inv.SDBI_Last_DIFF, '0001-01-01 00:00:00') < datetime('now', '-1 day', 'localtime') AND
NOT           EXISTS (
                  SELECT 1
                    FROM SQL_DB_Ignore_List il
                   WHERE il.il_server = inv.SDBI_Server AND
                         il.il_name = inv.SDBI_name AND
                         il_type = 'Weekly'
              )
AND
NOT           EXISTS (
                  SELECT 1
                    FROM SQL_DB_Ignore_List il
                   WHERE il.il_server = inv.SDBI_Server AND
                         il.il_name = inv.SDBI_name AND
                         il_type = 'Monthly'
              )
             ) OR
             ( (inv.SDBI_Server IN (
                    SELECT IL_Server
                      FROM SQL_DB_Ignore_List
                     WHERE IL_name = inv.SDBI_name AND
                           il_type = 'Weekly'
                )
AND
                coalesce(inv.SDBI_Last_FULL, '0001-01-01 00:00:00') < datetime('now', '-7 days', 'localtime') ) AND
               coalesce(inv.SDBI_Last_DIFF, '0001-01-01 00:00:00') < datetime('now', '-7 days', 'localtime') ) OR
             ( (inv.SDBI_Server IN (
                    SELECT IL_Server
                      FROM SQL_DB_Ignore_List
                     WHERE IL_name = inv.SDBI_name AND
                           il_type = 'Monthly'
                )
AND
                coalesce(inv.SDBI_Last_FULL, '0001-01-01 00:00:00') < datetime('now', '-31 days', 'localtime') ) AND
               coalesce(inv.SDBI_Last_DIFF, '0001-01-01 00:00:00') < datetime('now', '-31 days', 'localtime') ) ) AND
           inv.SDBI_Server NOT IN (
               SELECT IL_Server
                 FROM SQL_DB_Ignore_List
                WHERE IL_name IS NULL AND
                      il_type = 'Backup'
           )
AND
NOT        EXISTS (
               SELECT 1
                 FROM SQL_DB_Ignore_List il
                WHERE il.il_server = inv.SDBI_Server AND
                      il.il_name = inv.SDBI_name AND
                      il_type = 'Backup'
           );

----------------------------------------------------------------------
-- Add a rows in the Analyse table to fix a bug where some data will be marked as current when it should
-- not after the server was down
----------------------------------------------------------------------
UPDATE Analyse_Query SET Analyse_Query_Order = Analyse_Query_Order + 1
WHERE Analyse_Query_Job_ID = 4
AND Analyse_Query_Order >= 5;

INSERT INTO Analyse_Query (
	  Analyse_Query_Name,
	  Analyse_Query_Job_ID,
	  Analyse_Query_Query,
	  Analyse_Query_Order,
	  Analyse_Query_Status,
	  Analyse_Query_Comment
  )
  VALUES (
		'Mark old ended rows in db inv table as not current if the database reappear',
		4,
		"UPDATE SQL_DB_Inventory SET SDBI_Current = 0 where SDBI_Current = 1 and SDBI_End is not null and SDBI_Server || SDBI_Name IN ( select SDBI_Server || SDBI_Name  from SQL_DB_Inv_Stage );",
		5,
		1,
		NULL
	);

----------------------------------------------------------------------
-- Add a VACUUM to release unused space following the purges
----------------------------------------------------------------------
INSERT INTO Analyse_Query (
	  Analyse_Query_Name,
	  Analyse_Query_Job_ID,
	  Analyse_Query_Query,
	  Analyse_Query_Order,
	  Analyse_Query_Status,
	  Analyse_Query_Comment
  )
  VALUES (
		'Vacuum to release unused space following the purges',
		2,
		"VACUUM;",
		9998,
		1,
		NULL
	);

----------------------------------------------------------------------
-- Add primary key to Prm_Jobs and change the data for the new list system
----------------------------------------------------------------------
BEGIN TRANSACTION;

DROP TABLE Prm_Jobs;

CREATE TABLE Prm_Jobs (
    JobId          INTEGER       NOT NULL
                                 PRIMARY KEY AUTOINCREMENT,
    JobType        NVARCHAR (50) NOT NULL
                                 COLLATE NOCASE,
    JobName        NVARCHAR (50) COLLATE NOCASE,
    JobServeurList INTEGER       NOT NULL,
    JobSqlID       INTEGER       NOT NULL,
    Client         NVARCHAR (50) COLLATE NOCASE,
    Status         INTEGER       DEFAULT 1,
    Comment        NVARCHAR (50) COLLATE NOCASE
);

INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (1, 'SQL Server', 'Inv SQL7', 1, 12, 'YPG', 1, 'DB Inventory for SQL Server 7');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (2, 'SQL Server', 'Inv SQL8', 2, 4, 'YPG', 1, 'DB Inventory for SQL Server 8 (2000)');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (3, 'SQL Server', 'Inv SQL9+', 4, 3, 'YPG', 1, 'DB Inventory for SQL Server 9 & up');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (4, 'SQL Server', 'Inv SQLExp', 3, 3, 'YPG', 1, 'DB Inventory for SQL Server Express');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (5, 'SQL Server', 'Job Inv SQL7 & 8', 6, 10, 'YPG', 1, 'Job Inventory for SQL Server 7 and 8');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (6, 'SQL Server', 'Job Inv SQL9+', 4, 7, 'YPG', 1, 'Job Inventory for SQL Server 9 & up');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (7, 'SQL Server', 'Job Hist SQL 7 & 8', 6, 8, 'YPG', 1, 'Job History for SQL Server 7 & 8');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (8, 'SQL Server', 'Job Hist SQL9+', 4, 8, 'YPG', 1, 'Job History for SQL Server 9 & Up');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (9, 'SQL Server', 'User Inv SQL 7 & 8', 6, 14, 'YPG', 1, 'User Inventory for SQL Server 7 & 8');
INSERT INTO Prm_Jobs (JobId, JobType, JobName, JobServeurList, JobSqlID, Client, Status, Comment) VALUES (10, 'SQL Server', 'User Inv SQL 9+', 4, 13, 'YPG', 1, 'User Inventory for SQL Server 9 & up');

COMMIT TRANSACTION;

----------------------------------------------------------------------
-- Add primary key to Prm_Listes and change the data for the new list system
-- Also adding value for mysql
----------------------------------------------------------------------
BEGIN TRANSACTION;

DROP TABLE Prm_Listes;
CREATE TABLE Prm_Listes (NoListe INTEGER NOT NULL, ServerType VARCHAR NOT NULL COLLATE NOCASE, Comment nvarchar (50) COLLATE NOCASE);
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (1, 'SQL7', 'SQL Server 7');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (2, 'SQL8', 'SQL Server 8 (2000)');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (3, 'SQLEXP', 'SQL Express (No agent, no jobs)');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (4, 'SQL', 'SQL Server 9+');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (5, 'ORACLE', 'ORACLE');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (6, 'SQL7', 'SQL Server 7 & 8');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (6, 'SQL8', 'SQL Server 7 & 8');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (11, 'ORACLE', 'ALL ORACLE SERVER');
INSERT INTO Prm_Listes (NoListe, ServerType, Comment) VALUES (21, 'MYSQL', 'ALL MYSQL');

COMMIT TRANSACTION;

----------------------------------------------------------------------
-- Add primary Key to Email_Job
----------------------------------------------------------------------
CREATE TABLE sqlitestudio_temp_table AS SELECT * FROM Email_Job;
DROP TABLE Email_Job;
CREATE TABLE Email_Job (Email_Job_ID INTEGER NOT NULL PRIMARY KEY,
    Email_Job_Name    VARCHAR (50)  COLLATE NOCASE,
    Email_Job_Subject VARCHAR (100) COLLATE NOCASE,
    Email_Job_Message VARCHAR       COLLATE NOCASE,
    Email_Job_Email   VARCHAR (500) COLLATE NOCASE,
    Email_Job_Tag     INTEGER,
    Email_Job_Order   INTEGER       NOT NULL,
    Email_Job_Status  INTEGER       NOT NULL,
    Email_Job_Freq    VARCHAR (50)  COLLATE NOCASE,
    Email_Job_Comment VARCHAR       COLLATE NOCASE
);

INSERT INTO Email_Job (Email_Job_ID,Email_Job_Name, Email_Job_Subject, Email_Job_Message, Email_Job_Email, Email_Job_Tag, Email_Job_Order, Email_Job_Status, Email_Job_Freq, Email_Job_Comment) SELECT Email_Job_ID, Email_Job_Name, Email_Job_Subject, Email_Job_Message, Email_Job_Email, Email_Job_Tag, Email_Job_Order, Email_Job_Status, Email_Job_Freq, Email_Job_Comment FROM sqlitestudio_temp_table;
DROP TABLE sqlitestudio_temp_table;
CREATE UNIQUE INDEX Email_Job_UQ__Email_Jo__8B35AB0B59FA5E80 ON Email_Job (Email_Job_ID DESC);

----------------------------------------------------------------------
-- Add primary Key to SQL_DB_Ignore_List
----------------------------------------------------------------------
CREATE TABLE sqlitestudio_temp_table AS SELECT * FROM SQL_DB_Ignore_List;
DROP TABLE SQL_DB_Ignore_List;
CREATE TABLE SQL_DB_Ignore_List (
    IL_Id      INTEGER       NOT NULL
                             PRIMARY KEY,
    IL_Server  VARCHAR (60)  NOT NULL
                             COLLATE NOCASE,
    IL_name    VARCHAR (60)  COLLATE NOCASE,
    IL_Type    VARCHAR (30)  COLLATE NOCASE,
    IL_Status  VARCHAR (30)  COLLATE NOCASE,
    IL_Comment VARCHAR (100) COLLATE NOCASE
);
INSERT INTO SQL_DB_Ignore_List (IL_Id, IL_Server, IL_name, IL_Type, IL_Status, IL_Comment) SELECT IL_Id, IL_Server, IL_name, IL_Type, IL_Status, IL_Comment FROM sqlitestudio_temp_table;
DROP TABLE sqlitestudio_temp_table;

----------------------------------------------------------------------
-- Add the column Connection_String to Prm_Server
-- Rename Column Oracle_Port to Port in Prm_Server
----------------------------------------------------------------------
ALTER TABLE Prm_Server RENAME TO sqlitestudio_temp_table;

CREATE TABLE Prm_Server (
    ServerID          INTEGER       NOT NULL
                                    PRIMARY KEY,
    SGBD              NVARCHAR (50) COLLATE NOCASE,
    serverName        NVARCHAR (50) NOT NULL
                                    COLLATE NOCASE,
    Optional_Host     NVARCHAR (50),
    Oracle_Database   NVARCHAR (50) COLLATE NOCASE,
    Port              INTEGER,
    UID               INTEGER,
    OS                NVARCHAR (50) COLLATE NOCASE,
    DTQAP             NVARCHAR (50) COLLATE NOCASE,
    Status            INTEGER       DEFAULT 1,
    Comment           NVARCHAR (50) COLLATE NOCASE
);

INSERT INTO Prm_Server (ServerID, SGBD, serverName, Oracle_Database, Port, UID, OS, DTQAP, Status, Comment)
   SELECT ServerID, SGBD, serverName, Oracle_Database, Oracle_Port, UID, OS, DTQAP, Status, Comment
   FROM sqlitestudio_temp_table;

DROP TABLE sqlitestudio_temp_table;

CREATE UNIQUE INDEX Prm_Server_UQ__Prm_Serv__C56AC8871CF15040 ON Prm_Server (ServerID DESC);
CREATE UNIQUE INDEX Prm_Server_UQ__Prm_Serv__C56AC8871FCDBCEB ON Prm_Server (ServerID DESC);

PRAGMA foreign_keys = 1;
