# SAJOB

V1.1 Changelog :

- Added Monthly exception for backup
- Added a vacuum at the end of the analysis to release the unused space from purge
- Added Linux support (SQL server support from oracle still in progress)
- Remade the collector system to reduce the number of connection to one per server instead of on per job per server
- Remade the list system to ease the list management


- Fixed a bug where a removed database would stay mark as current even if a new row for the database was add.
