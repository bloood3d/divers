# coding=utf-8

import os
import sys
import datetime
import time
from os import walk

# SAJOB version : 1.0.0
# This script is the starting point of SAJOB, it starts each module in order.
# See each python script for more info on them.
# All the output is redirect to a logfile to easily track error.

# Used to remove old log files
def cleanupOldLog():
    keep = 30  # config['days_to_keep_logs']
    removed = 0
    folder = sajobPath + '\Log'
    if os.name == 'posix':
        folder = sajobPath + '/Log'
    time_in_secs = time.time() - (keep * 86400)

    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        if os.stat(file_path).st_mtime < time_in_secs:
            if os.path.isfile(file_path):
                print file_path
                removed += 1
                os.remove(file_path)

    print ('The log file cleanup removed ' + str(removed) + ' files')

# ### Start point ### #

# Config Variable:
sajobPath = 'C:\Users\Simon\Desktop\SAJOB\SAJOB'

# In UNIX, directory separator are / while they are \ in windows
# So we need 2 separate block of code depending on the OS
if os.name == 'posix':
    # Empty folder are not copied from Github, this is to create it the first time
    if not os.path.exists(sajobPath + '/Log'):
        os.makedirs(sajobPath + '/Log')

    # Create a new logfile with now date and time
    logfile = open(sajobPath + "/Log/Sajob_" + str(datetime.datetime.now().strftime("%Y%m%d-%H%M%S")) + ".log", "w")
    print ('Log file available at ' + logfile.name)

    sys.stdout = logfile
    sys.stderr = logfile

    print ("*** process started at " + str(datetime.datetime.now()) + " ***")

    os.chdir(sajobPath + '/Param_Gen')
    print ('*** Executing ' + sajobPath + '/Param_Gen/Param_Gen.py ***')
    execfile(sajobPath + '/Param_Gen/Param_Gen.py')

    os.chdir(sajobPath + '/Collector')
    print ('*** Executing ' + sajobPath + "/Collector/Collector.py ***")
    execfile(sajobPath + "/Collector/Collector.py")

    os.chdir(sajobPath + '/Loader')
    print ('*** Executing ' + sajobPath + "/Loader/Loader.py ***")
    execfile(sajobPath + "/Loader/Loader.py")

    # os.chdir(sajobPath + '/Analyser')
    # print ('*** Executing ' + sajobPath + "/Analyser/Analyser.py ***")
    # execfile(sajobPath + "/Analyser/Analyser.py")

    # os.chdir(sajobPath + '/Emailer')
    # print ('*** Executing ' + sajobPath + "/Emailer/Emailer.py ***")
    # execfile(sajobPath + "/Emailer/Emailer.py")

else:
    # Empty folder are not copied from Github, this is to create it the first time
    if not os.path.exists(sajobPath + '\Log'):
        os.makedirs(sajobPath + '\Log')

    # Create a new logfile with now date and time
    logfile = open(sajobPath + "\Log\Sajob_" + str(datetime.datetime.now().strftime("%Y%m%d-%H%M%S")) + ".log", "w")
    print ('Log file available at ' + logfile.name)

    sys.stdout = logfile
    sys.stderr = logfile

    print ("*** process started at " + str(datetime.datetime.now()) + " ***")

    os.chdir(sajobPath + '\Param_Gen')
    print ('*** Executing ' + sajobPath + '\Param_Gen\Param_Gen.py ***')
    execfile(sajobPath + '\Param_Gen\Param_Gen.py')

    os.chdir(sajobPath + '\Collector')
    print ('*** Executing ' + sajobPath + "\Collector\Collector.py ***")
    execfile(sajobPath + "\Collector\Collector.py")

    os.chdir(sajobPath + '\Loader')
    print ('*** Executing ' + sajobPath + "\Loader\Loader.py ***")
    execfile(sajobPath + "\Loader\Loader.py")

    # os.chdir(sajobPath + '\Analyser')
    # print ('*** Executing ' + sajobPath + "\Analyser\Analyser.py ***")
    # execfile(sajobPath + "\Analyser\Analyser.py")

    # os.chdir(sajobPath + '\Emailer')
    # print ('*** Executing ' + sajobPath + "\Emailer\Emailer.py ***")
    # execfile(sajobPath + "\Emailer\Emailer.py")

cleanupOldLog()

print ("*** process completed at " + str(datetime.datetime.now()) + " *** \n")

# Uncomment below row
# input("prompt: ")